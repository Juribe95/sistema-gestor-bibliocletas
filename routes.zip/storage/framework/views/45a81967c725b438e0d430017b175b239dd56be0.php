<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="public/css/bootstrap.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <div class="row vertical-offset-100">
        <div class="col-md-4 col-md-offset-4">
        <?php if(isset($_COOKIE['password_updated'])):?>
            <div class="alert alert-success">
            <p><i class='glyphicon glyphicon-off'></i> Se ha cambiado la contraseña exitosamente !!</p>
            <p>Pruebe iniciar sesion con su nueva contraseña.</p>

            </div>
        <?php setcookie("password_updated","",time()-18600);
         endif; ?>
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Iniciar Sesion</h3>
                </div>
                <div class="panel-body">
                    <form accept-charset="UTF-8" role="form" method="post" action="index.php?view=processlogin">
                    <fieldset>
                        <div class="form-group">
                            <input class="form-control" placeholder="Usuario" name="mail" type="text">
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="Contraseña" name="password" type="password" value="">
                        </div>
                        <input class="btn btn-lg btn-primary btn-block" type="submit" value="Iniciar Sesion">
                    </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\sgb\resources\views/welcome.blade.php ENDPATH**/ ?>