<?php $__env->startSection('title','galery'); ?>

<?php $__env->startSection('content'); ?>

	<h1>galery</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgb\resources\views/galery.blade.php ENDPATH**/ ?>