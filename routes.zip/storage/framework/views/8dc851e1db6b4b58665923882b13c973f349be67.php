<?php $__env->startSection('title','Inicio Voluntario'); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('parte1'); ?>
    <h1 class="w3-text-teal embed-responsive-item">Inicio de Voluntario</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta alias optio, quisquam blanditiis, molestias unde ut quibusdam aperiam fugit quo rem ipsam laborum? Tempore reiciendis, veritatis voluptatum placeat laborum quis?</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum sit quia pariatur similique voluptates facere deserunt ex, beatae odio autem dolor, ullam provident commodi dignissimos labore officiis fugiat qui eum.</p>

    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla-voluntario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgb\resources\views/inicio-voluntario.blade.php ENDPATH**/ ?>