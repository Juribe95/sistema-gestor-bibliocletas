<?php $__env->startSection('title','login'); ?>



<?php echo $__env->make('plantilla-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgb\resources\views/login.blade.php ENDPATH**/ ?>