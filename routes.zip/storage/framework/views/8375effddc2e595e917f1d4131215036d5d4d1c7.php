<?php $__env->startSection('title','contact'); ?>

<?php $__env->startSection('content'); ?>

	<h1>contact</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgb\resources\views/contact.blade.php ENDPATH**/ ?>