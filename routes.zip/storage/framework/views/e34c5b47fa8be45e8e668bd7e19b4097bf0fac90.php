<?php $__env->startSection('title','login'); ?>



<?php echo $__env->make('Plantilla-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgb\resources\views/Login.blade.php ENDPATH**/ ?>