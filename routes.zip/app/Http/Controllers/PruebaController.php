<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class PruebaController extends Controller{
    public function prueba(){
        return 'Estoy en el controlador de prueba';
    }
}
