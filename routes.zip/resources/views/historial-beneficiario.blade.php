
@extends('plantilla-beneficiario')

@section('title','Inicio Beneficiario')

@section('content')
    @section('parte1')
    <h1 class="w3-text-teal embed-responsive-item">Historial de Pedidos</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit tenetur, ducimus magnam quod labore cum officiis. Ipsam facere, iusto ducimus consectetur, odit aperiam esse sequi corporis, quis assumenda nesciunt deserunt!</p>


    @endsection
@endsection
