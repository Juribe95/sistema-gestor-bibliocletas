
@extends('plantilla-beneficiario')

@section('title','Inicio Beneficiario')

@section('content')
    @section('parte1')
    <h1 class="w3-text-teal embed-responsive-item">Catalogo</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat fuga modi, praesentium debitis, et quod consectetur harum, ex voluptates iste autem assumenda nemo cupiditate labore mollitia aliquid veritatis nesciunt explicabo?</p>


    @endsection
@endsection
