@extends('Plantilla-admin')

@section('title','Eliminar Libro')