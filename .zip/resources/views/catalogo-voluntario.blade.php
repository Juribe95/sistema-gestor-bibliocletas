
@extends('plantilla-voluntario')

@section('title','Catalogo Voluntario')

@section('content')
    @section('parte1')
    <h1 class="w3-text-teal embed-responsive-item">Catalogo Voluntario</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta alias optio, quisquam blanditiis, molestias unde ut quibusdam aperiam fugit quo rem ipsam laborum? Tempore reiciendis, veritatis voluptatum placeat laborum quis?</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum sit quia pariatur similique voluptates facere deserunt ex, beatae odio autem dolor, ullam provident commodi dignissimos labore officiis fugiat qui eum.</p>

    @endsection
@endsection
