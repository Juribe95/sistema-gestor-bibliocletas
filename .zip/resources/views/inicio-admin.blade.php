
@extends('Plantilla-admin')

@section('title','login')

@section('content')
    @section('parte1')
    <h1 class="w3-text-teal embed-responsive-item">Bienvenido a la Biblioteca de la agrupacion abanico</h1>
    <div class="embed-responsive embed-responsive-16by9">
        <iframe src="https://www.youtube.com/embed/LSlGfZfM3Us" frameborder="0" all="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>


    @endsection
@endsection
