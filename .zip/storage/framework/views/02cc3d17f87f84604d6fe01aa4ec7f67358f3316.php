<?php $__env->startSection('title','Inicio Beneficiario'); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('parte1'); ?>
    <h1 class="w3-text-teal embed-responsive-item">Historial de Pedidos</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit tenetur, ducimus magnam quod labore cum officiis. Ipsam facere, iusto ducimus consectetur, odit aperiam esse sequi corporis, quis assumenda nesciunt deserunt!</p>


    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla-beneficiario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgb\resources\views/historial-beneficiario.blade.php ENDPATH**/ ?>