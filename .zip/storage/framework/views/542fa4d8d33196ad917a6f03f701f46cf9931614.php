<?php $__env->startSection('title','Inicio Beneficiario'); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('parte1'); ?>
    <h1 class="w3-text-teal embed-responsive-item">Catalogo</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat fuga modi, praesentium debitis, et quod consectetur harum, ex voluptates iste autem assumenda nemo cupiditate labore mollitia aliquid veritatis nesciunt explicabo?</p>


    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla-beneficiario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgb\resources\views/catalogo-beneficiario.blade.php ENDPATH**/ ?>