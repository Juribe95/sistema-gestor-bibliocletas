<?php $__env->startSection('title','login'); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('parte1'); ?>
    <h1 class="w3-text-teal embed-responsive-item">Bienvenido a la Biblioteca de la agrupacion abanico</h1>
    <div class="embed-responsive embed-responsive-16by9">
        <iframe src="https://www.youtube.com/embed/LSlGfZfM3Us" frameborder="0" all="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>


    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Plantilla-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sgb\resources\views/inicio-admin.blade.php ENDPATH**/ ?>